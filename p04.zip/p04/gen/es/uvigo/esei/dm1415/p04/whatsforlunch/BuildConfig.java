/** Automatically generated file. DO NOT MODIFY */
package es.uvigo.esei.dm1415.p04.whatsforlunch;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package es.uvigo.esei.dm1415.p04.whatsforlunch.ClasesVisual;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import es.uvigo.esei.dm1415.p04.whatsforlunch.R;


public class FragmentListarTipoComidas extends Fragment {


}
